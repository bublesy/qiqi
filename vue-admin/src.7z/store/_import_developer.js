module.exports = file => require('@/views' + file).default // vue-loader at least v13.0.0+
