<template>
  <div class="app-container">
    <h2 style="margin-left:10%">钉类管理</h2>
    <el-form :inline="true" :model="form" size="mini">
      <el-form-item label="部门名称:">
        <el-input clearable @clear="getList" />
      </el-form-item>
      <el-button type="primary" size="mini" @click="toQuery">查询</el-button>
      <el-button type="primary" size="mini" @click="dialogVisible = true">新增 </el-button>
    </el-form>
    <el-table
      :data="tableData"
      border
      style="width: 400px"
    >
      <el-table-column
        type="index"
        label="#"
      />
      <el-table-column
        prop="date"
        label="钉类名称"
      />
      <el-table-column
        prop="name"
        label="操作"
        width="150"
      >
        <template>
          <el-button size="mini" type="warning" @click="dialogVisible = true">编辑</el-button>
          <el-button size="mini" type="danger">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 新增/编辑对话框 -->
    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      width="30%"
      :before-close="handleClose"
    >
      <el-form :inline="true" :model="form" size="mini">
        <el-form-item label="钉类名称:">
          <el-input />
        </el-form-item>

      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 分页 -->
    <el-pagination
      size="mini"
      :current-page="currentPage4"
      :page-sizes="[100, 200, 300, 400]"
      :page-size="100"
      layout="total, sizes, prev, pager, next, jumper"
      :total="400"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
  </div>
</template>
<script>
export default {
  name: 'Nails',
  data() {
    return {
      dialogVisible: false,
      tableData: [{
        date: '2016-05-02',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1518 弄'
      }, {
        date: '2016-05-04',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1517 弄'
      }, {
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        date: '2016-05-03',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1516 弄'
      }],
      currentPage1: 5,
      currentPage2: 5,
      currentPage3: 5,
      currentPage4: 4
    }
  },
  methods: {
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
        })
        .catch(_ => {})
    }
  }
}
</script>
<style scoped>

</style>
